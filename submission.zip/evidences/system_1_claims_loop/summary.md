# Run summary — 20260925_023207

- Model: `claude-haiku-4-5-20251001`
- Fixtures processed: 8
- Estimated total cost: **$0.1277** USD

| claim_id | outcome | claim_type | severity | turns | clarifications_asked | input_tokens | output_tokens | est_cost_usd | elapsed_s |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| claim_01_kitchen_fire | incomplete | - | - | 2 | 0 | 6277 | 448 | 0.0085 | 4.8 |
| claim_02_stolen_bike | incomplete | - | - | 2 | 0 | 6157 | 384 | 0.0081 | 3.7 |
| claim_03_water_damage | incomplete | - | - | 3 | 0 | 9203 | 486 | 0.0116 | 5.8 |
| claim_04_neighbor_injury | routed | liability | high | 6 | 0 | 22344 | 1035 | 0.0275 | 14.7 |
| claim_05_auto_collision | routed | auto | high | 4 | 0 | 14945 | 951 | 0.0197 | 10.3 |
| claim_06_low_confidence_escalation | incomplete | - | - | 3 | 0 | 9470 | 583 | 0.0124 | 7.6 |
| claim_07_tree_falls_on_car | routed | auto | medium | 4 | 0 | 14238 | 850 | 0.0185 | 11.5 |
| claim_08_minor_porch_damage | routed | property_damage | low | 5 | 0 | 17285 | 827 | 0.0214 | 10.1 |
