# Reflection Brief — Harness Engineering Capstone

**Name:*Shabana .D. Guledgudd*
**Date:*27-09-2026*

Replace each `→` with your answer. **Every answer cites at least one artifact from your own runs** — a run ID, file path, token count, claim outcome, or test count. Uncited answers do not pass. 3–6 sentences each unless noted. Paste short artifact snippets where they help.

**Environment**

- Model(s): Not recorded in the captured Multi-Shift run artifacts.
- OS / Python: Linux / Python 3.13.0, pytest 8.4.2.
- Approx. API spend: $0 for the captured shift smoke test because it used a recorded offline response.

---

## Part 1 — Per-system

### System 1 — Agentic loop

1. **Loop control.** Quote the `stop_reason` sequence from one trace. Name the file and function that decides continue-vs-stop, and how.
   In claims_intake/loop.py, the loop is controlled by the model's stop_reason. The sequence from runs/20260925_023207/traces/claim_04_neighbor_injury.jsonl is tool_use → tool_use → tool_use → tool_use → tool_use → end_turn. The run_agentic_loop function uses while True, continues only when response.stop_reason == "tool_use", returns when it is "end_turn", and raises UnexpectedStopReason for any other value. This avoids using a fixed iteration count as the primary stopping mechanism.

2. **Anti-pattern.** Name one anti-pattern `test_antipatterns.py` checks for. What would break in your run if the loop used it?
   One anti-pattern checked by tests/test_antipatterns.py is using string-membership tests such as "some_token" in model_output to control the loop. The test also checks that the loop does not use an integer-literal iteration cap such as range(10) or while turn < 10. If the loop used either pattern, the anti-pattern tests would fail even if an individual run appeared successful. The implementation instead uses the structured response.stop_reason value and the Budget safety mechanism.

3. **Tool design.** Pick two tools with overlapping inputs. How do the descriptions prevent misrouting? What did a structured tool error let the agent do that a generic string would not?
   Two tools with overlapping claim-related inputs are classify_claim and route_to_adjuster: both deal with the claim type, but their descriptions give them different responsibilities. classify_claim commits to a claim type and confidence, while route_to_adjuster is explicitly a terminal tool that routes the already-classified claim and requires classification and severity first. The tools also return structured errors containing is_error, error_category, is_retryable, and message. This lets the model distinguish, for example, a permanent invalid input from a retryable failure instead of receiving an unstructured error string.

4. **Your numbers.** Quote the turn count and cost for one claim. How does it differ from the README sample, and why?
   For claim_04_neighbor_injury, the run took 6 turns. The trace shows five tool_use turns followed by end_turn; the claim was ultimately routed to the liability queue. The run summary reports 22,344 input tokens, 1,035 output tokens, and an estimated cost of $0.0275, with an elapsed time of 14.7 seconds. These numbers are specific to my run and may differ from the README's sample because the model responses, token usage, and fixture execution timing can differ between runs.

### System 2 — Context strategy

5. **The reduction.** From `budget.json`: baseline tokens, assembled tokens, reduction %. Which section dominates the assembled context, and why keep it verbatim?
   The baseline transcript contained 38,708 tokens, while the assembled context contained 16,850 tokens, giving a 56.47% reduction (runs/20260925-113814/budget.json). The assembled context was dominated by the active section at 15,789 tokens, compared with 204 tokens for case facts, 396 for resolved/refund, and 479 for resolved/subscription. The active segment is kept verbatim because it represents the customer's current unresolved issue and must not be altered by lossy summarization.

6. **Summarize vs preserve.** State the rule for what gets summarized vs kept byte-exact, citing your per-section token numbers.
   The strategy summarizes resolved segments while preserving the active segment byte-exact. In this run, the resolved refund section was compressed to 396 tokens and the resolved subscription section to 479 tokens, while the active section remained 15,789 tokens (budget.json). The case-facts block was also kept as a compact structured section at 204 tokens. This separates historical information that can tolerate compression from the live issue where exact wording and details may still matter.

7. **Facts block.** Compare `eval.jsonl` to `eval_control.jsonl`. Which question regressed, and what does that prove?
   In the normal evaluation, both Q1 and Q6 passed: Q1 correctly returned the $22.14 refund and Q6 returned the exact structured status in_progress (eval.jsonl). In the case-facts-stripped control, Q1 still passed unexpectedly, but Q6 failed because the model said that no structured status token was assigned (eval_control.jsonl). This demonstrates that the case-facts block provides information that is necessary for reliably recovering the structured payment-update status, while the refund amount remained recoverable from other parts of the compressed context. The unexpected Q1 pass also shows that the control does not prove every fact depends exclusively on the case-facts block.

### System 3 — Claude Code config

8. **Path-scoped rules.** Quote the glob frontmatter from one rule file. Why is it better than a directory-level CLAUDE.md for cross-cutting conventions?
   The React rule in .claude/rules/react.md uses the glob frontmatter src/components/**/* and src/pages/**/*, while .claude/rules/api.md uses src/api/**/*. This means the relevant conventions load automatically based on the files being edited rather than applying to the entire repository. This is better than putting all cross-cutting conventions in a directory-level CLAUDE.md because React-specific and API-specific guidance stays targeted to the code it governs. The tests confirmed this behavior: React files match the React rule, API files match the API rule, and test files match the appropriate combined rules.

9. **Forked skill.** Quote the `context: fork` and `allowed-tools` lines. What does running forked + read-only buy you? What breaks without it?
   .claude/skills/deploy-check/SKILL.md specifies context: fork and an allowed-tools list containing only read-oriented operations such as Read, Grep, Glob, and restricted Git/GitHub commands. Running it forked keeps verbose deployment-check discovery output out of the main session while returning only the structured summary. The read-only allowlist also prevents the skill from modifying files, pushing changes, or deploying. Without the fork, the intermediate discovery output would contaminate the main session; without the restricted tools, the check would have a larger modification/deployment blast radius.

10. **Scope.** From the validator output: project-level vs user-level scope. Give one example of each from this config.
    The validator confirmed that the configuration is project-scoped, with python -m ecommerce_team_config . returning OK and all 35 tests passing. An example of project-level configuration is .claude/commands/review.md, which defines the team's shared /review command inside the repository. The deploy-check skill is another project-level example at .claude/skills/deploy-check/SKILL.md. The configuration also explicitly describes a possible user-level variant such as ~/.claude/skills/deploy-check-strict/ for personal customization; that path is described in the skill documentation rather than being present in the find output.

### System 4 — Orchestration

11. **Push work down.** Defects the SQL query returned vs warm-tier total. Name the indexed query. Why does the model never see the full history?
    The captured Shift C run reported `new=0`, so the SQL query returned 0 defects newer than the supplied `--since 2026-04-29T22:00:00Z` cutoff during that run. The fixture tests establish that the warm store contains at least 30 defect rows, while `defects_since()` applies `WHERE ts > ?`, `ORDER BY ts DESC`, and `LIMIT ?` inside SQLite. The query uses the `(shift, ts)` index, with the System 1 test verifying that the query plan uses the index. Because filtering and limiting happen in SQLite before prompt construction, the model does not receive the full warm-tier history.

12. **Crash recovery.** The resume-vs-fresh decision and its staleness threshold (`recovery.py`). Why is a fresh start with an injected summary sometimes more reliable than resuming?
    The recovery logic uses a 30-minute staleness threshold. If the manifest is incomplete and the last step is 30 minutes old or less, recovery returns resume; after 30 minutes it returns fresh, while an empty or complete manifest also starts fresh. The tests explicitly verify the 30-minute boundary and the 31-minute case, with the 30-minute case passing as resume and the 31-minute case passing as fresh. A fresh start with the persisted summary can therefore avoid relying on stale or incomplete intermediate state while still retaining the important prior shift information.

13. **Small state.** Byte size of your `hot_state.json`. Why does the budget matter for a system run once per shift, indefinitely?
    The captured `data/hot_state.json` is 643 bytes, well below the approximately 5 KB budget. The state also caps `recent_defect_hashes` at 20 entries, as verified by the tiered-state tests. This prevents persistent state and future prompts from growing indefinitely as more shifts are processed. The 643-byte measurement is recorded in `evidence/04-quality-monitoring-02-invocation-pipeline/hot_state_size.txt`.

---

## Part 2 — Synthesis

*Graded on connecting two or more systems. Cite a named file/artifact from each.*

14. **Three layers.** Point to a file/artifact for each layer and justify.
    Model: shift_monitor/invocation.py and the recorded Claude client — the invocation builders define the context and prompt shape supplied to the model.
    Harness: shift_monitor/pipeline.py — the pipeline controls the invocation sequence, including reading state, querying defects, calling the client, updating state, and writing the scratchpad.
    Orchestration: shift_monitor/recovery.py, manifest.py, and fork.py — these handle concerns across multiple invocations, including crash recovery, persistent state, hypothesis forking, and scratchpad merging.
    Artifacts: `02-invocation-pipeline/solution/evidence/04-quality-monitoring-02-invocation-pipeline/pytest.txt` (15 passed), `03-crash-recovery/solution/evidence/04-quality-monitoring-03-crash-recovery/pytest.txt` (29 passed), and `04-fork-scratchpad/solution/evidence/04-quality-monitoring-04-fork-scratchpad/pytest.txt` (33 passed).

15. **Deterministic vs prompt.** Cite one behavior guaranteed in code (terminal tool, read-only allowlist, atomic write, byte budget) and one guided by prompt. When is each right?
    Some rules are enforced directly in code, such as the HotState size limit, the 20-hash limit, SQL-side filtering, and atomic state writes. Other decisions are prompt-guided, such as interpreting the defect evidence and producing the shift-quality summary; the recorded Shift C response reported 3 high and 2 medium defects and recommended lot quarantine. Deterministic enforcement is appropriate for storage, recovery, and safety boundaries, while prompt guidance is useful for judgment-based analysis of quality data. The System 4 test run passed all 33 tests, including the state, recovery, and fork behavior.

16. **Context, two faces.** Compare context management in System 2 (intra-session) and System 4 (cross-session) with cited numbers from both. Same principle, different mechanism — how?
    System 2 manages context within one continuous conversation by compressing resolved segments while preserving the active segment and case-facts block. System 4 works across separate shift invocations by filtering defects at the SQL layer and persisting only a small structured state snapshot. In System 4, the captured hot-state file was only 643 bytes, while the SQL layer prevents the full defect history from being passed to the model. Both approaches follow the same principle: don't make the model process information it doesn't currently need.

17. **Reliability you can't see in one run.** Name one behavior a test guarantees that a single successful run would not reveal. Why does it matter before shipping?
    Tests for exact boundaries, such as the 30-minute recovery cutoff and 20-hash state limit, catch failures that a normal successful run might never expose. The crash-recovery suite specifically passed the 30-minute resume case and the 31-minute fresh case, while the tiered-state suite passed the more-than-20-hashes rejection test. Production eventually encounters edge cases, so testing those boundaries before deployment provides confidence that recovery and state management work correctly.

18. **Blast radius.** Pick one system. What's the blast radius if it misbehaves, and what's the kill switch? Ground it in that system's tools, enforcement points, and state.
    The fork-scratchpad system limits the blast radius of hypothesis exploration by copying the base hot state into an isolated fork directory before experimentation. The test test_fork_for_hypothesis_copies_state_without_mutating_base confirms that the base state remains unchanged, while test_two_forks_produce_independent_scratchpads verifies that separate hypotheses do not share scratchpad state. Findings only return to the main scratchpad through the explicit merge operation, which appends the fork entries rather than rewriting existing history. The final System 4 run passed all 33 tests, including these isolation and merge checks.

---

## Part 3 — Honest assessment

19. **What broke.** One thing that failed first try in your environment, and how you fixed it. (If nothing, what you checked to be sure.)
    The first attempt to run the documented `.venv/bin/pytest` command failed because `.venv/bin/pytest` did not exist in the solution environment. I checked the installed environment and found Python 3.13.0 and pytest 8.4.2 available, so I switched to `python -m pytest`. The System 1 test suite then completed successfully with 9 passed tests, followed by 15 passed for System 2, 29 passed for System 3, and 33 passed for System 4. This confirmed that the test environment itself was usable even though the documented `.venv` executable was unavailable.

20. **What you'd change.** One architectural decision you'd make differently, grounded in what you observed.
    I would make the environment setup explicit and reproducible so the documented `.venv/bin/pytest` commands work immediately rather than requiring a fallback to the available Python environment. The initial missing `.venv` executable caused the only setup failure during my captured verification, while all four test suites subsequently passed using `python -m pytest`. A pinned environment or lockfile would make the execution instructions more consistent across machines and reduce environment-related setup friction. The final System 4 verification produced 33 passed tests.